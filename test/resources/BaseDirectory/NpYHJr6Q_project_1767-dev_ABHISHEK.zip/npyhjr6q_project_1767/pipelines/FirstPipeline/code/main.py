from firstpipeline.pipeline import main

main()